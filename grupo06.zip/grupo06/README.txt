ROVER:
	Tecla 0: Mover Esquerda
	Tecla 1: Mover Direita
	Limites: Limite Esquerdo e Direito do Ecrã

INIMIGO:
	Tecla 4: Desce inimigo
	Limites: Linha acima do Rover

Display:
	Tecla 3: Incrementa valor no Display
	Tecla 7: Decrementa valor no Display
	Limites: 0-100, em decimal 